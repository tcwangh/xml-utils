package ntut.csie.sslab.team.entity.model.team;

public enum Role {
    CompanyAdmin, TeamAdmin, Member
}
