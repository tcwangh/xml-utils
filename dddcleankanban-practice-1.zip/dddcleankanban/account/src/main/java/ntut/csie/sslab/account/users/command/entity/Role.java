package ntut.csie.sslab.account.users.command.entity;

public enum Role {
    Manager, User;
}
