package ntut.csie.sslab.kanban.usecase.workflow;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class WorkflowTestRepository implements WorkflowRepository2 {
    private List<Workflow2> workflows = new ArrayList<>();

    @Override
    public void save(Workflow2 workflow) {
        workflows.add(workflow);
    }

    @Override
    public Optional<Workflow2> getById(String workflowId) {
        for (Workflow2 workflow : workflows) {
            if (workflow.getWorkflowId().equals(workflowId)) {
                return Optional.of(workflow);
            }
        }
        return Optional.empty();
    }
}
