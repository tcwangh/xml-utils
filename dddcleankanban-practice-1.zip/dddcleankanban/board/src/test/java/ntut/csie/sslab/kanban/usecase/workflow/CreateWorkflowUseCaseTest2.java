package ntut.csie.sslab.kanban.usecase.workflow;

import com.google.common.eventbus.Subscribe;
import ntut.csie.sslab.ddd.adapter.gateway.GoogleEventBusAdapter;
import ntut.csie.sslab.ddd.usecase.DomainEventBus;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import java.util.Optional;

public class CreateWorkflowUseCaseTest2 {

    @Test
    public void test_create_workflow() {

        WorkflowRepository2 workflowRepository2 = new WorkflowTestRepository();
        DomainEventBus eventBus = new GoogleEventBusAdapter();
        FakeListener listener = new FakeListener();
        eventBus.register(listener);

        CreateWorkflowUseCase2 workflowUseCase2 = new CreateWorkflowUseCase2(workflowRepository2, eventBus);
        CreateWorkflowInput2 input = new CreateWorkflowInput2();
        CreateWorkflowOutput2 output = new CreateWorkflowOutput2();
        input.setBoardId("1");
        input.setWorkflowId("123");
        input.setWorkflowName("test");

        workflowUseCase2.execute(input, output);

        Optional<Workflow2> queryResult = workflowRepository2.getById("123");

        Assertions.assertTrue(queryResult.isPresent());
        Workflow2 workflow2 = queryResult.get();
        Assertions.assertEquals(input.getBoardId(), workflow2.getBoardId());
        Assertions.assertEquals(input.getWorkflowId(), workflow2.getWorkflowId());
        Assertions.assertEquals(input.getWorkflowName(), workflow2.getWorkflowName());

        Assertions.assertEquals(1, listener.getCount());

        // UI -> web controller layer -> service layer -> db layer
        //  UI -> web controller layer -> usercase layer (entity + event) -> db layer
    }

    public class FakeListener {
        private int count = 0;

        @Subscribe
        public void execute(Object object) {
            count++;
        }

        public int getCount() {
            return count;
        }
    }

}
