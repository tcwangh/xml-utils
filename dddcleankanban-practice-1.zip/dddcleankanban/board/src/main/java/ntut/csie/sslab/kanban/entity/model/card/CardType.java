package ntut.csie.sslab.kanban.entity.model.card;

public enum CardType {
    General, Expedite
}
