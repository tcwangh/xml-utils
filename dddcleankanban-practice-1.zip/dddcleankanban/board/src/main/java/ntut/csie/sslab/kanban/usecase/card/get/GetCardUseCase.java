package ntut.csie.sslab.kanban.usecase.card.get;

import ntut.csie.sslab.ddd.usecase.UseCase;

public interface GetCardUseCase extends UseCase<GetCardInput, GetCardOutput> {
}
