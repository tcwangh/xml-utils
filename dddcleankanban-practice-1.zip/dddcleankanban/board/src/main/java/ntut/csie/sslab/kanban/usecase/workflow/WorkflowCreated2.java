package ntut.csie.sslab.kanban.usecase.workflow;

import ntut.csie.sslab.ddd.model.DomainEvent;

import java.util.Date;

public class WorkflowCreated2 extends DomainEvent {
    public WorkflowCreated2(Date occurredOn) {
        super(occurredOn);
    }
}
