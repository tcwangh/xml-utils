package ntut.csie.sslab.kanban.usecase.workflow;

import ntut.csie.sslab.ddd.usecase.DomainEventBus;
import ntut.csie.sslab.kanban.entity.model.workflow.Workflow;

public class CreateWorkflowUseCase2 {

    private WorkflowRepository2 repository;
    private DomainEventBus eventBus;

    public CreateWorkflowUseCase2(WorkflowRepository2 repository, DomainEventBus eventBus) {
        this.repository = repository;
        this.eventBus = eventBus;
    }

    public void execute(CreateWorkflowInput2 input, CreateWorkflowOutput2 output2) {
        Workflow2 workflow = new Workflow2(input.getBoardId(), input.getWorkflowId(), input.getWorkflowName());

        repository.save(workflow);
        eventBus.postAll(workflow);

        output2.setBoardId(input.getBoardId());
        output2.setWorkflowId(input.getWorkflowId());
        output2.setWorkflowName(input.getWorkflowName());
    }
}
