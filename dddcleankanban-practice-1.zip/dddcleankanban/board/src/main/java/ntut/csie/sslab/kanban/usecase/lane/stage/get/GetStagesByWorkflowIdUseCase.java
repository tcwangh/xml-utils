package ntut.csie.sslab.kanban.usecase.lane.stage.get;

import ntut.csie.sslab.ddd.usecase.UseCase;

public interface GetStagesByWorkflowIdUseCase extends UseCase<GetStagesByWorkflowIdInput, GetStagesByWorkflowIdOutput> {

}
