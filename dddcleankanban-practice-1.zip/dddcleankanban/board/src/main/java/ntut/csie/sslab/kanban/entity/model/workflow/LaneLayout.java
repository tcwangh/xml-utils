package ntut.csie.sslab.kanban.entity.model.workflow;

public enum LaneLayout {
    Vertical,Horizontal
}
