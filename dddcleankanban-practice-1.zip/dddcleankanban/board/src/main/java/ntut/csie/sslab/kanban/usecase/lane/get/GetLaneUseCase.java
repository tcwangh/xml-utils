package ntut.csie.sslab.kanban.usecase.lane.get;

import ntut.csie.sslab.ddd.usecase.UseCase;

public interface GetLaneUseCase extends UseCase<GetLaneInput, GetLaneOutput> {
}
