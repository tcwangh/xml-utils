package ntut.csie.sslab.ddd.adapter.presenter;

public interface ViewModel {
}
