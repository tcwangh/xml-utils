package ntut.csie.sslab.kanban.usecase.workflow;

import com.google.common.eventbus.Subscribe;
import ntut.csie.sslab.ddd.usecase.DomainEventBus;
import ntut.csie.sslab.kanban.entity.model.board.Board;
import ntut.csie.sslab.kanban.entity.model.board.CommittedWorkflow;
import ntut.csie.sslab.kanban.usecase.board.BoardRepository;
import org.glassfish.jersey.server.model.Suspendable;

import java.util.List;
import java.util.Optional;

public class NotifyBoardHandler2 {

    BoardRepository boardRepository;
    DomainEventBus eventBus;

    public NotifyBoardHandler2(BoardRepository boardRepository, DomainEventBus eventBus) {
        this.boardRepository = boardRepository;
        this.eventBus = eventBus;
    }

    @Subscribe
    public void whenReceive(WorkflowCreated2 workflowCreated2) {
//        // step 1 find board
        Board board = boardRepository.findById(workflowCreated2.getBoardId()).get();
//        // step 2 baord add workflow
        List<CommittedWorkflow> committedWorkflowList = board.getCommittedWorkflows();
        committedWorkflowList.add(new CommittedWorkflow(workflowCreated2.getBoardId(), workflowCreated2.getWorkflowId(), committedWorkflowList.size()));
        boardRepository.save(board);
    }
}
