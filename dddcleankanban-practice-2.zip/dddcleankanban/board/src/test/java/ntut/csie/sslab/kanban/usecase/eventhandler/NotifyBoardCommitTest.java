package ntut.csie.sslab.kanban.usecase.eventhandler;

import ntut.csie.sslab.ddd.adapter.gateway.GoogleEventBusAdapter;
import ntut.csie.sslab.ddd.adapter.presenter.cqrs.CqrsCommandPresenter;
import ntut.csie.sslab.ddd.usecase.DomainEventBus;
import ntut.csie.sslab.ddd.usecase.cqrs.CqrsCommandOutput;
import ntut.csie.sslab.kanban.entity.model.board.Board;
import ntut.csie.sslab.kanban.usecase.board.BoardRepository;
import ntut.csie.sslab.kanban.usecase.board.create.CreateBoardInput;
import ntut.csie.sslab.kanban.usecase.board.create.CreateBoardUseCase;
import ntut.csie.sslab.kanban.usecase.board.create.CreateBoardUseCaseImpl;
import ntut.csie.sslab.kanban.usecase.workflow.*;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import java.util.Optional;

public class NotifyBoardCommitTest {

    DomainEventBus eventBus = new GoogleEventBusAdapter();
    BoardRepository boardRepository = new InMemoryBoardRepository();

    @Test
    public void test_commit_workflow() {
        NotifyBoardHandler2 notifyBoard = new NotifyBoardHandler2(boardRepository, eventBus);
        eventBus.register(notifyBoard);

        String boardId = create_board();
        Board board = boardRepository.findById(boardId).get();
        Assertions.assertEquals(0, board.getCommittedWorkflows().size());
        String workflowId = create_workflow(boardId);

        board = boardRepository.findById(boardId).get();
        Assertions.assertEquals(1, board.getCommittedWorkflows().size());
    }

    public String create_board() {

        CreateBoardUseCase createBoardUseCase = new CreateBoardUseCaseImpl(boardRepository, eventBus);
        CreateBoardInput input = createBoardUseCase.newInput();
        input.setTeamId("1");
        input.setName("test");
        input.setUserId("123");
        CqrsCommandOutput output = CqrsCommandPresenter.newInstance();

        createBoardUseCase.execute(input, output);
        return output.getId();
    }

    public String create_workflow(String boardId) {

        WorkflowRepository2 workflowRepository2 = new WorkflowTestRepository();
        CreateWorkflowUseCase2 workflowUseCase2 = new CreateWorkflowUseCase2(workflowRepository2, eventBus);
        CreateWorkflowInput2 input = new CreateWorkflowInput2();
        CreateWorkflowOutput2 output = new CreateWorkflowOutput2();
        input.setBoardId(boardId);
        input.setWorkflowId("123");
        input.setWorkflowName("test");

        workflowUseCase2.execute(input, output);

        Optional<Workflow2> queryResult = workflowRepository2.getById("123");

        return queryResult.get().getWorkflowId();
    }
}
