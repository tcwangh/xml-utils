package ntut.csie.sslab.kanban.usecase.workflow;

import ntut.csie.sslab.kanban.entity.model.board.Board;
import ntut.csie.sslab.kanban.usecase.board.BoardRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class InMemoryBoardRepository implements BoardRepository {

    List<Board> boards = new ArrayList<>();

    @Override
    public List<Board> getBoardsByUserId(String userId) {
        return null;
    }

    @Override
    public List<Board> getBoardsByProjectId(String projectId) {
        return null;
    }

    @Override
    public List<Board> findAll() {
        return null;
    }

    @Override
    public Optional<Board> findById(String boardId) {
        for (Board board : boards) {
            if (board.getBoardId().equals(boardId)) {
                return Optional.of(board);
            }
        }
        return Optional.empty();
    }

    @Override
    public void save(Board data) {
        boards.add(data);
    }

    @Override
    public void deleteById(String s) {

    }
}
