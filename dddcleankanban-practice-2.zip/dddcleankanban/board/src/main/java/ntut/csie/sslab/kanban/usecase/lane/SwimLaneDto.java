package ntut.csie.sslab.kanban.usecase.lane;

public class SwimLaneDto extends LaneDto {
    public SwimLaneDto() {
        super();
    }

}
