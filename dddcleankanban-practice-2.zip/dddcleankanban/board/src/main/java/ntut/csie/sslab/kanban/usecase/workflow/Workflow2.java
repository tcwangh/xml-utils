package ntut.csie.sslab.kanban.usecase.workflow;

import ntut.csie.sslab.ddd.model.AggregateRoot;

import java.util.Date;

public class Workflow2 extends AggregateRoot<String> {
    private String boardId;
    private String workflowId;
    private String workflowName;

    public Workflow2(String boardId, String workflowId, String workflowName) {
        super(workflowId);
        this.boardId = boardId;
        this.workflowId = workflowId;
        this.workflowName = workflowName;

        this.addDomainEvent(new WorkflowCreated2(new Date(), boardId, workflowId, workflowName));
    }

    public String getBoardId() {
        return boardId;
    }

    public void setBoardId(String boardId) {
        this.boardId = boardId;
    }

    public String getWorkflowId() {
        return workflowId;
    }

    public void setWorkflowId(String workflowId) {
        this.workflowId = workflowId;
    }

    public String getWorkflowName() {
        return workflowName;
    }

    public void setWorkflowName(String workflowName) {
        this.workflowName = workflowName;
    }
}
