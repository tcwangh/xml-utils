package ntut.csie.sslab.kanban.usecase.card.edit;

import ntut.csie.sslab.ddd.usecase.UseCase;

public interface EditCardUseCase extends UseCase<EditCardInput, EditCardOutput>{

}
