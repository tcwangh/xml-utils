package ntut.csie.sslab.kanban.usecase.workflow.get;

import ntut.csie.sslab.ddd.usecase.UseCase;

public interface GetWorkflowUseCase extends UseCase<GetWorkflowInput, GetWorkflowOutput> {
}
