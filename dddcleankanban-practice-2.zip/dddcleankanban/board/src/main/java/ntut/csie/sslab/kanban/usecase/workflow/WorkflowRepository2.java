package ntut.csie.sslab.kanban.usecase.workflow;

import java.util.Optional;

public interface WorkflowRepository2 {
    void save(Workflow2 workflow);

    Optional<Workflow2> getById(String workflowId);
}
