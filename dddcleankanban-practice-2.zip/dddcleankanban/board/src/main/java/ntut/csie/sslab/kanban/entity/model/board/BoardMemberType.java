package ntut.csie.sslab.kanban.entity.model.board;

public enum BoardMemberType {
    Manager, Member
}
