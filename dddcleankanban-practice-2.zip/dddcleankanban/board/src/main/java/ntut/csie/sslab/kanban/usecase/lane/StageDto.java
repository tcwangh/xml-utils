package ntut.csie.sslab.kanban.usecase.lane;

public class StageDto extends LaneDto {
    public StageDto() {
        super();
    }
}
