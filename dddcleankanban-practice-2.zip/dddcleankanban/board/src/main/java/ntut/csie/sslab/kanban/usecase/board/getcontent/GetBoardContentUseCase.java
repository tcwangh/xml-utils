package ntut.csie.sslab.kanban.usecase.board.getcontent;

import ntut.csie.sslab.ddd.usecase.UseCase;

public interface GetBoardContentUseCase extends UseCase<GetBoardContentInput, GetBoardContentOutput> {

}
