package ntut.csie.sslab.kanban.entity.model.workflow;

public enum LaneType {
    Standard, IceBox, Backlog, Archive
}
