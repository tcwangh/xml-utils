package ntut.csie.sslab.kanban.usecase.workflow;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class WorkflowRepositoryImpl2 implements WorkflowRepository2 {

    private List<Workflow2> workflows = new ArrayList<>();

    @Override
    public void save(Workflow2 workflow) {
        workflows.add(workflow);
    }

    @Override
    public Optional<Workflow2> getById(String workflowId) {
//        workflows.stream().filter(x->x.getWorkflowId())
        return Optional.empty();
    }
}
